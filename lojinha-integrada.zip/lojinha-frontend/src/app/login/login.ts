import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClienteService } from '../services/cliente-service';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {
  email:string = "";
  senha:string = "";
  mensagem = signal("");

  constructor(private service:ClienteService){}

  fazerLogin(){
    this.mensagem.set("");
    this.service.fazerLogin(this.email, this.senha).subscribe({
      next:(cliente) =>{
        if(cliente.codigo > 0){
          localStorage.setItem("cliente", JSON.stringify(cliente));
          let cesta = JSON.parse(localStorage.getItem("cesta") ?? "[]");
          if(cesta.length > 0){
            location.href = "pedido";
          } else {
            this.mensagem.set("Seja bem vindo, " + cliente.nome + "!!");
          }
        } else {
          this.mensagem.set("Senha ou usuário invalido!");
        }
      },
      error:(err) =>{
        this.mensagem.set("Ocorreu um erro, tente mais tarde!");
      }
    });
  }

}
