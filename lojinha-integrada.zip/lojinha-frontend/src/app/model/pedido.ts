export class Pedido {
    codigoPedido:number=0;
    valorTotal:number=0;
    entrega:string="";
    obs:string="";
    codigoCliente:number=0;
}
