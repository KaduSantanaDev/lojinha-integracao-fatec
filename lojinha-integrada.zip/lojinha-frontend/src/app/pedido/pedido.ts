import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Cliente } from '../model/cliente';
import { ItemCesta } from '../model/item-cesta';
import { Pedido as PedidoModel } from '../model/pedido';
import { PedidoService } from '../services/pedido-service';
import { mensagemErro } from '../services/api';

@Component({
  imports: [FormsModule],
  selector: 'app-pedido',
  styleUrl: './pedido.css',
  templateUrl: './pedido.html',
})
export class Pedido {
  cliente: Cliente | null = null;
  obj: PedidoModel = new PedidoModel();
  itens = signal<ItemCesta[]>([]);
  mensagem = signal("");
  erro = signal(false);
  enviando = signal(false);

  constructor(private service:PedidoService){}

  ngOnInit(){
    let jsonCliente = localStorage.getItem("cliente");
    if(jsonCliente != null){
      this.cliente = JSON.parse(jsonCliente);
    }
    let jsonCesta = localStorage.getItem("cesta");
    if(jsonCesta != null){
      this.itens.set(JSON.parse(jsonCesta));
    }
    this.obj.valorTotal = 0;
    for(let itm of this.itens()){
      this.obj.valorTotal += itm.valorTotal;
    }
    this.obj.valorTotal = Math.round(this.obj.valorTotal * 100) / 100;
    if(this.cliente != null){
      this.obj.codigoCliente = this.cliente.codigo;
      this.obj.entrega = this.cliente.logradouro;
    }
  }

  confirmarPedido(){
    if(this.obj.entrega.trim().length == 0){
      this.erro.set(true);
      this.mensagem.set("Informe o endereço de entrega!");
      return;
    }
    this.enviando.set(true);
    this.service.gravar(this.obj).subscribe({
      next:(msg) =>{
        this.erro.set(false);
        this.mensagem.set(msg);
        this.enviando.set(false);
        localStorage.removeItem("cesta");
        this.itens.set([]);
      },
      error:(err) =>{
        this.erro.set(true);
        this.mensagem.set(mensagemErro(err));
        this.enviando.set(false);
      }
    });
  }
}
