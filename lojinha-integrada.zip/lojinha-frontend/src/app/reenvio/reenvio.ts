import { Component, signal } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { ClienteService } from '../services/cliente-service';
import { mensagemErro } from '../services/api';

@Component({
  imports: [FormsModule],
  selector: 'app-reenvio',
  styleUrl: './reenvio.css',
  templateUrl: './reenvio.html',
})
export class Reenvio {
  email: string = "";
  senhaAtual: string = "";
  novaSenha: string = "";
  mensagem = signal("");
  erro = signal(false);

  constructor(private service:ClienteService){}

  resetarSenha(){
    if(this.email.trim().length == 0){
      this.erro.set(true);
      this.mensagem.set("Informe o seu email!");
      return;
    }
    this.service.resetarSenha(this.email).subscribe({
      next:(msg) =>{
        this.erro.set(false);
        this.mensagem.set(msg + " Use a senha temporária para cadastrar uma nova senha ao lado.");
      },
      error:(err) =>{
        this.erro.set(true);
        this.mensagem.set(mensagemErro(err));
      }
    });
  }

  alterarSenha(form:NgForm){
    if(form.invalid || this.email.trim().length == 0){
      this.erro.set(true);
      this.mensagem.set("Preencha o email, a senha atual e uma nova senha válida!");
      return;
    }
    this.service.alterarSenha(this.email, this.senhaAtual, this.novaSenha).subscribe({
      next:(msg) =>{
        this.erro.set(false);
        this.mensagem.set(msg);
        this.senhaAtual = "";
        this.novaSenha = "";
        form.resetForm();
      },
      error:(err) =>{
        this.erro.set(true);
        this.mensagem.set(mensagemErro(err));
      }
    });
  }
}
