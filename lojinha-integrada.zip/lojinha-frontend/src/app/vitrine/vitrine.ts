import { Component, signal } from '@angular/core';
import { Produto } from '../model/produto';
import { CommonModule } from '@angular/common';
import { ItemCesta } from '../model/item-cesta';
import { ProdutoService } from '../services/produto-service';

@Component({
  imports: [CommonModule],
  selector: 'app-vitrine',
  styleUrl: './vitrine.css',
  templateUrl: './vitrine.html',
})
export class Vitrine {
  lista = signal<Produto[]>([]);
  mensagem = signal("");

  constructor(private service:ProdutoService){}

  ngOnInit(){
    this.mensagem.set("");
    this.service.carregarVitrine().subscribe({
      next:(dados) =>{
        this.lista.set(dados);
        if(dados.length <=0) this.mensagem.set("não existem produto na vitrine!");
      },
      error: (err) =>{
        this.mensagem.set("Ocorreu um erro, tente mais tarde!");
      }
    });

  }

  verDetalhe(obj:Produto){
    localStorage.setItem("produto", JSON.stringify(obj));  
    location.href = "detalhe";
  }

  adicionarItem(obj:Produto){
    let cesta : ItemCesta[] = [];
    let achou : boolean = false;

    let json = localStorage.getItem("cesta");
    if(json!=null) {
      cesta = JSON.parse(json);
      for(let itm of cesta){
        if(itm.produto.codigo == obj.codigo) {
            itm.quantidade++;
            itm.valorTotal = itm.valorVenda * itm.quantidade;  
            achou = true;
        }    
      }
    } 
    if(!achou) cesta.push(new ItemCesta(obj));
    
    localStorage.setItem("cesta", JSON.stringify(cesta));
    location.href="cesta";
  }

}
