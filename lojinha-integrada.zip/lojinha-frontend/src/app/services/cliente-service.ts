import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cliente } from '../model/cliente';
import { API_URL } from './api';

@Injectable({
  providedIn: 'root',
})
export class ClienteService {

    constructor(private http: HttpClient){}

    public gravar(obj: Cliente): Observable<string> {
        return this.http.post(API_URL + '/cliente', obj, { responseType: 'text' });
    }

    public fazerLogin(email: string, senha: string): Observable<Cliente> {
        return this.http.post<Cliente>(API_URL + '/cliente/login', { email, senha });
    }

    public resetarSenha(email: string): Observable<string> {
        return this.http.patch(API_URL + '/cliente/resetarSenha', { email }, { responseType: 'text' });
    }

    public alterarSenha(email: string, senhaAtual: string, novaSenha: string): Observable<string> {
        return this.http.patch(API_URL + '/cliente/alterarSenha',
            { email, documento: senhaAtual, senha: novaSenha }, { responseType: 'text' });
    }

}
