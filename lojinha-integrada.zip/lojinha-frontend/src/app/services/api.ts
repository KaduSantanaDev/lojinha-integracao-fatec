import { HttpErrorResponse } from '@angular/common/http';

export const API_URL = 'http://localhost:8081/api';

export function mensagemErro(err: HttpErrorResponse): string {
  const corpo = err.error;
  if (err.status >= 400 && err.status < 500 && typeof corpo === 'string'
      && corpo.length > 0 && !corpo.startsWith('{')) {
    return corpo;
  }
  return 'Ocorreu um erro, tente mais tarde!';
}
