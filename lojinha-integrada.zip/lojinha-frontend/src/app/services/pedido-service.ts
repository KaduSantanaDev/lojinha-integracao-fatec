import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pedido } from '../model/pedido';
import { API_URL } from './api';

@Injectable({
  providedIn: 'root',
})
export class PedidoService {

    constructor(private http: HttpClient){}

    public gravar(obj: Pedido): Observable<string> {
        return this.http.post(API_URL + '/pedido', obj, { responseType: 'text' });
    }

}
