import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Produto } from '../model/produto';
import { API_URL } from './api';

@Injectable({
  providedIn: 'root',
})
export class ProdutoService {

    constructor(private http: HttpClient){}

    public carregarVitrine(): Observable<Produto[]> {
        return this.http.get<Produto[]>(API_URL + '/produto/vitrine');
    }

    public gravar(obj: Produto): Observable<string> {
        return this.http.post(API_URL + '/produto', obj, { responseType: 'text' });
    }

    public pesquisar(termo: string): Observable<Produto[]> {
        return this.http.get<Produto[]>(API_URL + '/produto/busca/' + encodeURIComponent(termo));
    }

}
