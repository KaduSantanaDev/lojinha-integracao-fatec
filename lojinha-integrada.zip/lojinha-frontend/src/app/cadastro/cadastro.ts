import { Component, signal } from '@angular/core';
import { Cliente } from '../model/cliente';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { ClienteService } from '../services/cliente-service';
import { mensagemErro } from '../services/api';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-cadastro',
  styleUrl: './cadastro.css',
  templateUrl: './cadastro.html',
})
export class Cadastro {
  obj:Cliente = new Cliente();
  mensagem = signal("");
  erro = signal(false);

  constructor(private service:ClienteService){}

  gravar(form:NgForm){
    if(form.invalid){
      this.erro.set(true);
      this.mensagem.set("Preencha todos os campos corretamente!");
      return;
    }
    this.service.gravar(this.obj).subscribe({
      next:(msg) =>{
        this.erro.set(false);
        this.mensagem.set(msg + " Agora é só fazer o login.");
        form.resetForm();
        this.obj = new Cliente();
      },
      error:(err) =>{
        this.erro.set(true);
        this.mensagem.set(mensagemErro(err));
      }
    });
  }
}
