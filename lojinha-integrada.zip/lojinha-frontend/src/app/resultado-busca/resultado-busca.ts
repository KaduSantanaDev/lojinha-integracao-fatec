import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Produto } from '../model/produto';
import { ProdutoService } from '../services/produto-service';
import { ItemCesta } from '../model/item-cesta';
import { FormsModule } from '@angular/forms';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-resultado-busca',
  styleUrl: './resultado-busca.css',
  templateUrl: './resultado-busca.html',
})
export class ResultadoBusca {
  lista = signal<Produto[]>([]);
  mensagem = signal("");
  termo:string="";

  constructor(private service:ProdutoService){}

  fazerBusca(){
    this.mensagem.set("");
    if(this.termo.trim().length == 0){
      this.mensagem.set("Informe um termo para a busca!");
      return;
    }
    this.service.pesquisar(this.termo).subscribe({
      next:(dados) =>{
        this.lista.set(dados);
        if(dados.length <=0) this.mensagem.set("não foram econtrados produtos com o termo:"+ this.termo);
        else this.mensagem.set("foram encontrados "+ dados.length + " produto(s)");
      },
      error: (err) =>{
        this.mensagem.set("Ocorreu um erro, tente mais tarde!");
      }
    });

  }

  verDetalhe(obj:Produto){
    localStorage.setItem("produto", JSON.stringify(obj));  
    location.href = "detalhe";
  }

  adicionarItem(obj:Produto){
    let cesta : ItemCesta[] = [];
    let achou : boolean = false;

    let json = localStorage.getItem("cesta");
    if(json!=null) {
      cesta = JSON.parse(json);
      for(let itm of cesta){
        if(itm.produto.codigo == obj.codigo) {
            itm.quantidade++;
            itm.valorTotal = itm.valorVenda * itm.quantidade;  
            achou = true;
        }    
      }
    } 
    if(!achou) cesta.push(new ItemCesta(obj));
    
    localStorage.setItem("cesta", JSON.stringify(cesta));
    location.href="cesta";
  }

}
